from imageswift.training import ImageModel
from imageswift.predicting import TrainedModel